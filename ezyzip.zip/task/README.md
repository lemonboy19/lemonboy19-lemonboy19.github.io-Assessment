# lemonboy19-lemonboy19.github.io-task

Essentially:
- This website is a collection of all my files that have been utilised throughout the design, creation, testing and deployment phases of the website component for IST Task 1 2022. 

- There are multple pages such as:
1) Homepage
2) About me 
3) Contact
4) Digital Media
5) The Internet